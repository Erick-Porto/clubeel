import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Endpoint de TESTE: POST /api/webhook-wpp
 *
 * Ao receber um POST, dispara um corpo fixo { message: "Webhook recebido" }
 * para o destino cravado abaixo. Não usa INTERNAL_LARA_API_URL nem o prefixo
 * /api — vai direto para a rota informada.
 */

const DEST_URL = 'http://192.168.100.48:3001/webhook-wpp';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }
  console.log("AAAAAAA");

  try {
    const backendResponse = await fetch(DEST_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ message: 'Webhook recebido' }),
    });

    // Repassa status + corpo da resposta do destino de volta ao chamador.
    const responseText = await backendResponse.text();
    const contentType = backendResponse.headers.get('content-type') ?? '';

    res.status(backendResponse.status);

    if (contentType.includes('application/json')) {
      try {
        return res.json(JSON.parse(responseText));
      } catch {
        return res.send(responseText);
      }
    }

    return res.send(responseText);
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Erro desconhecido';
    console.error(`[webhook-wpp] Falha ao enviar para ${DEST_URL}:`, message);
    return res.status(502).json({
      error: 'Proxy Connection Failed',
      detail: message,
    });
  }
}